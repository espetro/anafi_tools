## bebop_msgs

Common message definitions for `bebop_autonomy`.
