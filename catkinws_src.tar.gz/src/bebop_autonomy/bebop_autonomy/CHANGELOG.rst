^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package bebop_autonomy
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.7.0 (2017-07-29)
------------------

0.6.0 (2016-11-02)
------------------

0.5.1 (2016-05-04)
------------------

0.5.0 (2016-04-01)
------------------
* Add bebop_description package
* Contributors: Mani Monajjemi

0.4.1 (2016-02-17)
------------------

0.4.0 (2016-01-17)
------------------

0.3.0 (2015-09-17)
------------------
* New in 0.3.0
* Create ROS metapackage for bebop_autonomy
  - bebop_autonomy is the ROS metapackage name
  - Rename bebop_autonomy package to bebop_driver
  - Rename bebop_autonomy_msgs to bebop_msgs
* Contributors: Mani Monajjemi
