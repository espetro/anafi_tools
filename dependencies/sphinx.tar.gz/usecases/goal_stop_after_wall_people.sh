#!/bin/bash

# --datalog
sphinx --datalog $SPHINX_ROOT/worlds/goal_stop_after_wall_people.world \
       $SPHINX_ROOT/drones/local_anafi4k.drone \
       $SPHINX_ROOT/actors/pedestrian.actor::name=pedestrian0::machine=anafi4k::path=$SPHINX_ROOT/paths/goal_stop_after_wall_people_bot.path \
       $SPHINX_ROOT/actors/pedestrian.actor::name=subject::machine=anafi4k::path=$SPHINX_ROOT/paths/goal_stop_after_wall_people_subject.path