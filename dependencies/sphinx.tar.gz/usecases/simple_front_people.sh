#!/bin/bash

# pedestrian number IDs count from 0
# --datalog
# --datalog-rate=<rate>

sphinx --datalog $SPHINX_ROOT/worlds/simple_front_people.world \
       $SPHINX_ROOT/drones/local_bebop2.drone \
       $SPHINX_ROOT/actors/pedestrian.actor::name=pedestrian0::machine=bebop2::path=$SPHINX_ROOT/paths/simple_front_people1.path \
       $SPHINX_ROOT/actors/pedestrian.actor::name=pedestrian1::machine=bebop2::path=$SPHINX_ROOT/paths/simple_front_people2.path
